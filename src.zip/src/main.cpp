#include "boid.h"
#include "flock.h"
#include <raylib.h>

int main() {
  InitWindow(width, height, "FLOCKING SYSTEM 2D");
  Flock flock;
  for (int i = 0; i < 120; i++) {
    Boid boid({width / 2.0, height / 2.0});
    flock.addBoid(boid);
  }
  while (!WindowShouldClose()) {
    flock.run();
    BeginDrawing();
    ClearBackground(BLACK);
    EndDrawing();
  }
  CloseWindow();
  return 0;
}