#include "flock.h"
const int width = 1200;
const int height = 700;
