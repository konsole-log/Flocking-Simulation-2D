#pragma once
#include "boid.h"
#include <raylib.h>
#include <raymath.h>
#include <vector>
using namespace std;
struct Flock {
    vector<Boid> boids;
    Flock();
    void run();
    void addBoid(Boid &b);
};