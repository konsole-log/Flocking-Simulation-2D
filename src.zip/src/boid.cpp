#include "boid.h"
inline Vector2 rotate(Vector2 v, float a) {
  return {v.x * cosf(a) - v.y * sinf(a), v.x * sinf(a) + v.y * cosf(a)};
}
Boid::Boid(Vector2 pos) {
  acceleration = {0, 0};

  Vector2 vel = {(float)GetRandomValue(-100, 100),
                 (float)GetRandomValue(-100, 100)};

  velocity = Vector2Normalize(vel);
  velocity = Vector2Scale(velocity, maxspeed);
  position = pos;
  maxspeed = 3.0f;
  maxforce = 0.05f;
}
void Boid::applyForce(Vector2 force) {
  acceleration = Vector2Add(acceleration, force);
}
void Boid::flock(vector<Boid> &boids) {
  Vector2 sep = separate(boids);
  Vector2 ali = align(boids);
  Vector2 coh = cohere(boids);

  Vector2Scale(sep, 1.5f);
  Vector2Scale(ali, 1.0f);
  Vector2Scale(coh, 1.0f);

  applyForce(sep);
  applyForce(ali);
  applyForce(coh);
}
void Boid::update() {
  velocity = Vector2Add(velocity, acceleration);
  if (Vector2Length(velocity) > maxspeed) {
    velocity = Vector2Normalize(velocity);
    velocity.x = velocity.x * maxspeed;
    velocity.y = velocity.y * maxspeed;
  }
  position = Vector2Add(position, velocity);
  acceleration = {0, 0};
}
Vector2 Boid::seek(Vector2 &target) {
  Vector2 desired = Vector2Subtract(target, position);
  desired = Vector2Normalize(desired);
  desired = desired * maxspeed;
  Vector2 steer = Vector2Subtract(desired, velocity);
  if (Vector2Length(steer) > maxforce) {
    steer = Vector2Normalize(steer);
    steer.x = steer.x * maxforce;
    steer.y = steer.y * maxforce;
  }
  return steer;
}
void Boid::draw() {
  float angle = atan2f(velocity.y, velocity.x);
  Vector2 p1 = {size * 2, 0};
  Vector2 p2 = {-size * 2, -size};
  Vector2 p3 = {-size * 2, size};

  p1 = rotate(p1, angle);
  p2 = rotate(p2, angle);
  p3 = rotate(p3, angle);

  p1 = Vector2Add(p1, position);
  p2 = Vector2Add(p2, position);
  p3 = Vector2Add(p3, position);

  DrawTriangle(p1, p2, p3, WHITE);
}
void Boid::borders() {
  if (position.x < -size)
    position.x = width + size;
  if (position.y < -size)
    position.y = height + size;
  if (position.x > width + size)
    position.x = -size;
  if (position.y > height + size)
    position.y = -size;
}

Vector2 Boid::separate(vector<Boid> &boids) {
  float desiredSeparation = 25.0f;
  Vector2 steer = {0, 0};
  int count = 0;
  for (int i = 0; i < boids.size(); i++) {
    float dist = Vector2Distance(position, boids[i].position);
    if (dist > 0 && dist < desiredSeparation) {
      Vector2 diff = Vector2Subtract(position, boids[i].position);
      diff = Vector2Normalize(diff);
      diff.x = (float)(diff.x / dist);
      diff.y = (float)(diff.y / dist);
      steer = Vector2Add(steer, diff);
      count++;
    }
  }
  if (count > 0) {
    steer.x = (float)(steer.x / count);
    steer.y = (float)(steer.y / count);
  }
  if (Vector2Length(steer) > 0) {
    steer = Vector2Normalize(steer);
    steer.x = steer.x * maxspeed;
    steer.y = steer.y * maxspeed;
    steer = Vector2Subtract(steer, velocity);
    if (Vector2Length(steer) > maxforce) {
      steer = Vector2Normalize(steer);
      steer.x = steer.x * maxforce;
      steer.y = steer.y * maxforce;
    }
  }
  return steer;
}
Vector2 Boid::align(vector<Boid> &boids) {
  float neighborDistance = 50;
  Vector2 sum = {0, 0};
  int count = 0;
  for (int i = 0; i < boids.size(); i++) {
    float dist = Vector2Distance(position, boids[i].position);
    if (dist > 0 && dist < neighborDistance) {
      sum = Vector2Add(sum, boids[i].velocity);
      count++;
    }
  }
  if (count > 0) {
    sum = Vector2Scale(sum, (1 / count));
    sum = Vector2Normalize(sum);
    sum = Vector2Scale(sum, maxspeed);
    Vector2 steer = Vector2Subtract(sum, velocity);
    if (Vector2Length(steer) > maxforce) {
      steer = Vector2Normalize(steer);
      steer.x = steer.x * maxforce;
      steer.y = steer.y * maxforce;
    }
    return steer;
  } else {
    return {0, 0};
  }
}
Vector2 Boid::cohere(vector<Boid> &boids) {
  float neighborDistance = 50;
  Vector2 sum = {0, 0};
  int count = 0;
  for (int i = 0; i < boids.size(); i++) {
    float dist = Vector2Distance(position, boids[i].position);
    if (dist > 0 && dist < neighborDistance) {
      sum = Vector2Add(sum, boids[i].velocity);
      count++;
    }
  }
  if (count > 0) {
    sum = Vector2Scale(sum, (1 / count));
    return seek(sum);
  } else {
    return {0, 0};
  }
}

void Boid::run(vector<Boid> &boids) {
  flock(boids);
  update();
  borders();
  draw();
}
