#include "flock.h"
Flock::Flock() {
  boids = {};
}
void Flock::run() {
  for (auto &boid : boids) {
    boid.run(boids);
  }
}
void Flock::addBoid(Boid &b) {
  boids.push_back(b);
}