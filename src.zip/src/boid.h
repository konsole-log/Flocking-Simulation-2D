#pragma once
#include "config.h"
#include <raylib.h>
#include <raymath.h>
#include <vector>
using namespace std;
struct Boid {
    Vector2 position, velocity, acceleration;
    float size, maxspeed, maxforce;

    Boid(Vector2 pos);
    void run(vector<Boid> &boids);
    void applyForce(Vector2 force);
    void flock(vector<Boid> &boids);
    void update();
    Vector2 seek(Vector2 &target);
    void draw();
    void borders();

    Vector2 separate(vector<Boid> &boids);
    Vector2 align(vector<Boid> &boids);
    Vector2 cohere(vector<Boid> &boids);
};
